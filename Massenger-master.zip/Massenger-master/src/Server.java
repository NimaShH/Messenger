import java.io.*;
import java.net.*;
import java.util.List;
import java.util.ArrayList;

public class Server {
    static ArrayList<User> users = new ArrayList<User>();

    public static void main(String[] args) throws IOException {
        addAll();
        ServerSocket serverSocket = new ServerSocket(12345);
        while (true) {
            Socket socket = serverSocket.accept();
            ClientHandler clientHandler = new ClientHandler(socket);
            clientHandler.start();
        }
    }
    public static void addAll(){
        users.add(new User("qqqq","qqqq2024","123456"));
        users.add(new User("mmmm","mmmm2024","123456"));
        users.add(new User("wwww","wwww2024","123456"));
    }
}


