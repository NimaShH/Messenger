import java.io.*;
import java.net.*;
import java.util.List;

public class ClientHandler extends Thread {
    private Socket socket;
    private String name;
    private String username;
    private String password;
    private User me;
    private Generic contact;

    public ClientHandler(Socket socket) {
        this.socket = socket;
    }

    public void run() {

        try (InputStream input = socket.getInputStream();
            BufferedReader reader = new BufferedReader(new InputStreamReader(input));
            OutputStream output = socket.getOutputStream();
            PrintWriter writer = new PrintWriter(output, true)) {
            while(true) {
                writer.println("sign-up = enter 1   **   login = enter 2    **    delete = enter 3     (type 'exit' to quit)");
                String x = reader.readLine();
                switch (x) {
                    case "1":
                        writer.println("Enter first name and last name:");
                        name = reader.readLine();

                        writer.println("Enter username:");
                        username = reader.readLine();

                        writer.println("Enter password:");
                        password = reader.readLine();

                        synchronized (Server.users) {
                            Server.users.add(new User(name, username, password));
                            me = Server.users.getLast();
                        }
                    case "2":
                        if (x.equals("2")) {
                            boolean a = true;
                            while (a == true) {
                                writer.println("***** login *****");
                                writer.println("Enter username:");
                                String username = reader.readLine();

                                writer.println("Enter password:");
                                String password = reader.readLine();
                                for (User u : Server.users)
                                    if (password.equals(u.password) && username.equals(u.username)) {
                                        name = u.name;
                                        this.username = u.username;
                                        this.password = u.password;
                                        me = u;
                                        a = false;
                                    }
                                if (a == true) writer.println("!!! the password or username is incorrect !!!");
                            }
                        }
                        System.out.println("User " + name + " connected with password " + password);
                        menuwhile:
                        while (true) {
                            writer.println("send message : enter 1   **   get message : enter 2  **  logout : enter 3");
                            x = reader.readLine();
                            String text;
                            switch (x) {
                                case "1":
                                    writer.println("Enter the name of your contact :");
                                    String namecontact = reader.readLine();
                                    for (User u : Server.users) if (namecontact.equals(u.name)) contact = u.message;
                                    writer.println("Enter your message (type 'exit' to quit and type 'back' to previous page):");
                                    writer.flush();
                                    while ((text = reader.readLine()) != null) {
                                        if (text.equals("exit")) {
                                            return;
                                        }
                                        if (text.equals("back")) {
                                            break;
                                        }
                                        contact.addMessage("from_" + name + ":" + text);
                                        System.out.println("to_" + namecontact + "_from_" + name + " : " + text);
                                        writer.println(name + " : " + text);
                                    }
                                    break;
                                case "2":
                                    while (!me.message.isEmpty()) {
                                        writer.println(me.message.getMessage());
                                    }
                                    writer.println("-----END-----");
                                    break;
                                case "3":break menuwhile;
                            }
                        }
                        break;
                    case "3":
                        writer.println("***** delete *****");
                        writer.println("Enter username:");
                        String username = reader.readLine();

                        writer.println("Enter password:");
                        String password = reader.readLine();
                        boolean b = false;
                        for (User u : Server.users)
                            if (password.equals(u.password) && username.equals(u.username)){
                                Server.users.remove(u);
                                writer.println("successfull");
                                b = true;
                                break;
                            };
                        if (b == false)writer.println("Unsuccessfull");
                        break;
                    case "exit":
                        return;
                }
            }
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }
}
