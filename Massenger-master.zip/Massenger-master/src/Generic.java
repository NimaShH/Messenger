import java.util.LinkedList;

public class Generic <T>{
    private LinkedList<T> queue = new LinkedList<T>();
    public void addMessage(T message){
        queue.add(message);
    }
    public T getMessage(){
        return queue.poll();
    }
    public void clear(){
        queue.clear();
    }
    public boolean isEmpty(){
        return queue.isEmpty();
    }
}
