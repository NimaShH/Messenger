public class User {
    String name;
    String username;
    String password;
    Generic message = new Generic();

    User(String name,String username,String password) {
        this.name = name;
        this.username = username;
        this.password = password;
    }
}